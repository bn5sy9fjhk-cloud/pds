/* ================================================================
   admin-shell.js —— 独立后台页共享壳（admin/*.html）
   公共约定（唯一的公共：导航数据、缩放控件、当前页标注即读取 body.dataset）
   - 每个后台页都是真实独立 html，与本文件同兄弟目录；
   - 左栏为真实链接导航，不再做同页 SPA 路由切换；
   - 右上头像保留为登录态占位；“返回文件工作台”是真实回到 ../index.html 的链接；
   - 大 / 中 / 小 缩放与文件工作台共用 localStorage('htpds.scale')。
   依赖 admin-core.js(window.H) 与对应页面对应的 admin-pages-*.js(window.Routes)。
   ================================================================ */
(function () {
'use strict';
if (typeof window === 'undefined' || typeof document !== 'object') return;

var H = window.H;
if (!H) return;

var KEY = String(document.body.getAttribute('data-key') || 'overview');
var NAV = [
  { g: '运营', items: [['overview', '平台概览'], ['org', '组织与成员'], ['spaces', '空间管理'], ['perms', '空间成员权限']] },
  { g: '治理', items: [['filegov', '文件 / 回收站治理'], ['quota', '配额管理']] },
  { g: '审计与系统', items: [['audit', '审计日志'], ['syscfg', '系统配置']] }
];
var ICON = {
  overview: '<path d="M3 15h7v-9H3ZM12 15h5V9h-5Z" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linejoin="round"/>',
  org: '<path d="M2 4.5A1.5 1.5 0 0 1 3.5 3h4A1.5 1.5 0 0 1 9 4.5v3A1.5 1.5 0 0 1 7.5 9h-4A1.5 1.5 0 0 1 2 7.5ZM11 12.5A1.5 1.5 0 0 1 12.5 11H16a1.5 1.5 0 0 1 1.5 1.5v2A1.5 1.5 0 0 1 16 16h-3.5a1.5 1.5 0 0 1-1.5-1.5Z" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linejoin="round"/><path d="M10 4.5h2.5v5M14 14h2A1.5 1.5 0 0 1 17.5 12.5Z" fill="none" stroke="currentColor" stroke-width="1.4"/>',
  spaces: '<path d="M2.5 5.5A1.5 1.5 0 0 1 4 4h3l2 2h7A1.5 1.5 0 0 1 17.5 7.5v7A1.5 1.5 0 0 1 16 16H4a1.5 1.5 0 0 1-1.5-1.5Z" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linejoin="round"/>',
  perms: '<rect x="4" y="8.5" width="12" height="8" rx="1.5" fill="none" stroke="currentColor" stroke-width="1.5"/><path d="M7 8.5V6a3 3 0 0 1 6 0v2.5" fill="none" stroke="currentColor" stroke-width="1.5"/><circle cx="10" cy="12.5" r="1.1" fill="currentColor"/>',
  filegov: '<path d="M3 7.5A1.5 1.5 0 0 1 4.5 6h3l1.5 1.5H15A1.5 1.5 0 0 1 16.5 9v6A1.5 1.5 0 0 1 15 16.5H4.5A1.5 1.5 0 0 1 3 15Z" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linejoin="round"/>',
  quota: '<rect x="3" y="8" width="12.5" height="6" rx="1.5" fill="none" stroke="currentColor" stroke-width="1.5"/><path d="M3 9.5h9M7.5 14h-4M5.5 6v6" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>',
  audit: '<rect x="3.5" y="4" width="13" height="12" rx="1.5" fill="none" stroke="currentColor" stroke-width="1.5"/><path d="M6.5 8h7M6.5 11h7M6.5 14h4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>',
  syscfg: '<path d="M9 3h2l.6 2.1a5 5 0 0 1 1.3.6l2-.6 1.3 1.3-.6 2c.3.4.5.8.6 1.3l2 .6v2l-2 .6a5 5 0 0 1-.6 1.3l.6 2-1.3 1.3-2-.6c-.5.3-1 .5-1.3.6l-.6 2H9l-.6-2a5 5 0 0 1-1.3-.6l-2 .6-1.3-1.3.6-2a5 5 0 0 1-.6-1.3l-2-.6v-2l2-.6c.3-.5.5-.8.6-1.3l-.6-2 1.3-1.3 2 .6c.4-.3.8-.5 1.3-.6Z" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linejoin="round"/><circle cx="10" cy="10" r="2.6" fill="none" stroke="currentColor" stroke-width="1.4"/>'
};

function nameOf(k){ var t = k; for (var i = 0; i < NAV.length; i++){ for (var j = 0; j < NAV[i].items.length; j++){ if (NAV[i].items[j][0] === k) t = NAV[i].items[j][1]; } } return t; }

function buildTopbar(){
  var cur = document.querySelector('[data-cur]');
  if (cur) cur.textContent = nameOf(KEY);
  var docT = document.querySelector('title');
  if (docT) docT.textContent = '霍桐PDS · 管理中心 · ' + nameOf(KEY) + '（视觉验证原型）';
}
function buildNav(){
  var el = document.getElementById('mNav');
  if (!el) return;
  NAV.forEach(function (grp) {
    var sec = document.createElement('section');
    sec.className = 'a-nav__group';
    var p = document.createElement('h3');
    p.className = 'a-nav__label';
    p.textContent = grp.g;
    sec.appendChild(p);
    grp.items.forEach(function (it) {
      var k = it[0];
      var is = k === KEY;
      var a = document.createElement('a');
      a.className = 'a-nav-item' + (is ? ' a-nav-item--on' : '');
      a.href = k + '.html';
      a.innerHTML = '<svg viewBox="0 0 20 20" width="16" height="16" aria-hidden="true">' + (ICON[k] || '') + '</svg><span>' + it[1] + '</span>';
      sec.appendChild(a);
    });
    el.appendChild(sec);
  });
}

/* 缩放：小/中/大 逻辑已上收至共享 ui-scale.js —— 这里只做 UA 壳侧接线，
   不在此直接控制 zoom；视觉尺寸由 ui-base.css 的 [data-ui-scale] Token 决定。 */
function SC(){
  return (window.UIScale) ? window.UIScale : null;
}
function bootCurrent(){
  buildTopbar();
  buildNav();
  var n = document.querySelectorAll('#mNav .a-nav-item');
  for (var i = 0; i < n.length; i++) n[i].setAttribute('aria-current', n[i].getAttribute('href') === KEY + '.html' ? 'page' : 'false');
  /* 落档：交给共享 ui-scale.js（其上已覆盖 body[data-ui-scale] + 按钮高亮），仅确保已应用 */
  if (SC()) SC().apply(SC().read());
  /* 渲染当前页面对应唯一正文（对应脚本已按页面按其组引入） */
  var fn = window.Routes && window.Routes[KEY] ? window.Routes[KEY] : null;
  if (fn && typeof fn === 'function') { try { fn(); } catch (e) { if (window.console) window.console.error(e); } }
}
if (document.readyState === 'loading'){ document.addEventListener('DOMContentLoaded', bootCurrent); } else { bootCurrent(); }
})();
