/* ================================================================
   霍桐PDS · 管理端「运营与治理」页面模块  admin-pages-ops.js
   路由：overview 平台概览 / org 组织与成员 / spaces 空间管理 / perms 空间成员权限
   依赖：admin-core.js(window.H) · admin.css · ui-base.css（复用令牌，无裸色值）
   约定：不引第三方 / 不写持久化；全部数据为上提的本地 mock 常量（演示约定，
        非后端实时量），刷新即还原。替换数据仅需改各页面数据数组。
   ================================================================ */
(function(){
'use strict';
var H=window.H, esc=H.escape, ic=H.i, IC=H.IC;
window.Routes=window.Routes||{};
function pg(){ return H.root().querySelector('.a-page')||H.root(); }
function avatar(nm,cls){
  var AV=['var(--primary)','var(--ok)','var(--warn)','var(--danger)','#7a5ae0','#0e9b9b'];
  var h=7,i; for(i=0;i<nm.length;i++)h=(h*31+nm.charCodeAt(i))>>>0;
  return '<span class="'+(cls||'mem-avatar')+'" style="background:'+AV[h%AV.length]+'">'+esc(nm.charAt(0))+'</span>';
}

/* ============ 1) overview · 平台概览 · 演示 mock 数组即数据源 ============ */
var OV={
  kpi:[
    { k:'用户总数', v:'258',   d:'+12 近30日' },
    { k:'部门数',   v:'12',    d:'全部启用' },
    { k:'空间数',   v:'31',    d:'25 在用' },
    { k:'总配额',   v:'26', u:'TB', d:'已分配 24.3 TB' }
  ],
  cap:{ used:11.8, reserved:2.1, avail:12.1 },   // 三段和 = 26 TB
  drives:[
    { n:'研发部 部门盘',  used:5119, rev:0,   quota:10400 },
    { n:'生产部 部门盘',  used:1716, rev:410, quota:5175 },
    { n:'个人盘 · 张研',  used:238,  rev:0,   quota:1990 },
    { n:'管理中心 空间',  used:272,  rev:0,   quota:3400 }
  ],
  days:['09/01','09/02','09/03','09/04','09/05','09/06','09/07'],
  pts:[0.61,0.55,0.70,0.64,0.78,0.72,0.91],      // TB/日
  total:'近 7 日 4.2 TB', delta:'↑12%',
  acts:[
    { a:'系统管理员 张研', t:'关闭空间 · 生产部 · 已用超限告警', s:'今天 09:41', k:'warn' },
    { a:'用户 李明',       t:'上传 · 资源 /研发部/产品资料/DWG-041-工装.dwg', s:'今天 09:12', k:'up' },
    { a:'部门管理员 王磊', t:'初始化空间 · 新业务部（默认配额「部门盘 500 GB」）', s:'昨天 17:26', k:'x' },
    { a:'用户 周敏',       t:'移动 · 跨盘 /生产部/图纸 → /管理中心/文件', s:'昨天 15:03', k:'recycle' },
    { a:'平台管理员 张研', t:'变更成员权限 · 空间/研发部 · 李明 → 协作者', s:'昨天 11:48', k:'shield' },
    { a:'系统 密钥网关',   t:'轮换 · 应用密钥到期并自动重签', s:'昨天 10:02', k:'key' }
  ],
  alerts:[
    { k:'tag--danger', t:'1 个异步生成任务失败（预览渲染）· 待人工介入', m:'最近一次 09:20' },
    { k:'tag--danger', t:'对象预览失败率 2.4%（近 1h）· 网关判断为解析超时', m:'需重试' },
    { k:'tag--warn',   t:'平台管理员密钥 2 日后到期 · 已排队自动续期', m:'到期 09/08' }
  ]
};
function ovC3(){
  var u=+(OV.cap.used/26*100).toFixed(1), r=+(OV.cap.reserved/26*100).toFixed(1), a=(100-u-r).toFixed(1);
  return '<div class="c-flow"><div class="c3-legend" style="justify-content:flex-start;margin-bottom:6px;padding:0">'+
    '<span class="li"><span class="sw" style="background:var(--primary)"></span>已用 '+OV.cap.used+' TB</span>'+
    '<span class="li"><span class="sw" style="background:var(--warn)"></span>已预留 '+OV.cap.reserved+' TB</span>'+
    '<span class="li"><span class="sw" style="background:var(--color-border-light)"></span>可用 '+OV.cap.avail+' TB</span></div>'+
    '<span class="c3-track">'+
      '<span class="c3-seg c3-used"  style="width:'+u+'%" title="已用 11.8 TB"></span>'+
      '<span class="c3-seg c3-resv"  style="width:'+r+'%" title="已预留 2.1 TB"></span>'+
      '<span class="c3-seg c3-avail" style="width:'+a+'%" title="可用 12.1 TB"></span></span></div>';
}
function ovSpaces(){
  var s='';
  OV.drives.forEach(function(d){
    var uc=d.used/d.quota*100, rw=d.rev/Math.max(d.rev,0)&&d.rev?Math.min(d.rev/d.quota*100,100-uc):0;
    var pct=Math.min(uc+rw,100).toFixed(0);
    var title='已用 '+esc(H.fgb(d.used))+' · 预留 '+esc(H.fgb(d.rev))+' · 配额 '+esc(H.fgb(d.quota));
    s+='<div class="spacestrip" title="'+title+'"><span class="nm">'+ic(IC.recycle)+esc(d.n)+'</span>'+
      '<span class="bar">'+(d.used>0?'<i class="bu" style="width:'+uc.toFixed(1)+'%"></i>':'')+
      (d.rev?'<i class="br" style="width:'+rw.toFixed(1)+'%"></i>':'')+'</span>'+
      '<span class="cnt">'+pct+'%</span></div>';
  });
  return s;
}
function ovTrend(){
  var W=470,HH=160,m=18,t=10,b=HH-28,pts=OV.pts;
  var mn=Math.min.apply(null,pts),mx=Math.max.apply(null,pts),rg=(mx-mn)||0.01;
  function X(i){return m+(W-2*m)*(i/(pts.length-1));}
  function Y(v){return b-((b-t)*((v-mn)/rg));}
  var poly=[],line=[];
  pts.forEach(function(v,i){ poly.push(X(i).toFixed(0)+','+Y(v).toFixed(0)); line.push((i?'L':'M')+X(i).toFixed(0)+' '+Y(v).toFixed(0)); });
  var gid='o'+Math.floor(Math.random()*1000);
  return '<svg viewBox="0 0 '+W+' '+HH+'" style="display:block;width:100%;height:auto" role="img" aria-label="近7日上传量趋势（TB/日）">'+
    '<defs><linearGradient id="'+gid+'" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="var(--primary)" stop-opacity=".16"/><stop offset="1" stop-color="var(--primary)" stop-opacity="0"/></linearGradient></defs>'+
    '<polygon fill="url(#'+gid+')" points="'+X(0).toFixed(0)+','+b+' '+poly.join(' ')+' '+X(pts.length-1).toFixed(0)+','+b+'"/>'+
    '<polyline fill="none" stroke="var(--primary)" stroke-width="1.8" stroke-linecap="round" points="'+line.join(' ')+'"/></svg>';
}
function Routes_overview(){
  var st='',acts='',al='',dax='';
  OV.kpi.forEach(function(x){ st+='<div class="numstat"><div class="k">'+esc(x.k)+'</div><div class="v">'+esc(x.v)+(x.u?'<small>'+esc(x.u)+'</small>':'')+'</div><div class="d">'+esc(x.d)+'</div></div>'; });
  OV.acts.forEach(function(a){ acts+='<div class="recent-item"><span class="ri-ico">'+ic(IC[a.k]||IC.shield)+'</span>'+
      '<div class="rText"><div class="rMain"><b>'+esc(a.a)+'</b></div><div class="rSub">'+esc(a.t)+'</div></div>'+
      '<span class="rTime">'+esc(a.s)+'</span></div>'; });
  OV.alerts.forEach(function(x){ al+='<div style="display:flex;gap:10px;padding:6px 0;align-items:flex-start">'+
      '<span class="tag '+x.k+'" style="flex:none;margin-top:2px">'+(x.k==='tag--warn'?'提醒':'告警')+'</span>'+
      '<span style="color:var(--text-2);font-size:12px;line-height:1.5;flex:1">'+esc(x.t)+
      '<span class="u-faint" style="display:block;font-size:11px">'+esc(x.m)+'</span></span></div>'; });
  OV.days.forEach(function(d){ dax+='<span>'+esc(d)+'</span>'; });
  H.setPage(
    '<div class="a-head"><h1>平台概览</h1><span class="a-head__sub">演示 mock 数据（非后端实时量），替换仅需改本页 OV 数据数组</span></div>'+
    '<div class="num-strip">'+st+'</div>'+
    '<div class="cap3">'+ovC3()+'</div>'+
    '<div class="o-grid">'+
      '<div class="o-col">'+
        '<div class="panel"><div class="panel__head"><span class="t">空间用量 Top</span><span class="u">hover 可见 used / reserved / quota</span></div>'+
          '<div class="panel__body">'+ovSpaces()+'</div></div>'+
        '<div class="panel"><div class="panel__head"><span class="t">近7日上传量</span><span class="u">细趋势 · 单图</span></div>'+
          '<div class="tv-body"><div class="trend-head"><span class="big">'+esc(OV.total)+'</span><span class="up">&nbsp;'+esc(OV.delta)+'</span></div>'+
          ovTrend()+'<div class="trend-axis">'+dax+'</div></div></div>'+
      '</div>'+
      '<div class="o-col">'+
        '<div class="panel"><div class="panel__head"><span class="t">近期活动</span><span class="u">审计事件</span></div>'+
          '<div class="panel__body">'+acts+'</div></div>'+
        '<div class="panel"><div class="panel__head"><span class="t">告警与到期提醒</span><span class="u">一次性</span></div>'+
          '<div class="panel__body" style="padding:2px 14px 8px">'+al+'</div></div>'+
      '</div>'+
    '</div>');
}
Routes['overview']=Routes_overview;
/* ============ 2) org · 组织与成员 · 演示 mock ============ */
var ORG={
  tree:[
    { n:'总公司', c:258, sub:[
      { n:'研发部', c:126, sub:[ {n:'产品技术组',c:58},{n:'工艺设计组',c:30},{n:'测试验证组',c:38} ] },
      { n:'生产部', c:84,  sub:[ {n:'装配车间',c:52},{n:'质检组',c:32} ] },
      { n:'销售部', c:31 },
      { n:'管理中心', c:17, sub:[ {n:'行政',c:9},{n:'IT运维',c:8} ] }
    ]}
  ],
  roles:{ '平台管理员':'tag--primary', '部门管理员':'tag--warn', '成员':'tag--plain' },
  members:[
    { n:'张研', dept:'管理中心', role:'平台管理员', st:'ok',  ph:'138****2101', sp:2, last:'今天 09:32' },
    { n:'王磊', dept:'研发部',   role:'部门管理员', st:'ok',  ph:'139****7344', sp:2, last:'今天 08:47' },
    { n:'李明', dept:'研发部',   role:'成员',       st:'ok',  ph:'137****9812', sp:3, last:'昨天 21:15' },
    { n:'赵志', dept:'生产部',   role:'部门管理员', st:'ok',  ph:'150****2246', sp:1, last:'昨天 17:30' },
    { n:'周敏', dept:'管理中心', role:'部门管理员', st:'ok',  ph:'136****3308', sp:4, last:'09/05 16:02' },
    { n:'孙丽', dept:'销售部',   role:'成员',       st:'off', ph:'158****6642', sp:0, last:'09/01 10:44' }
  ]
};
function orgTreeHtml(){
  var out='';
  function walk(g,lv){
    out+='<div class="dt-row"'+(lv===0?' dt-row--on':'')+' style="padding-left:'+(8+lv*16)+'px" data-org="'+esc(g.n)+'" data-leaf="'+((g.sub&&g.sub.length)?0:1)+'">'+
      '<span class="dt-arrow'+(g.sub&&g.sub.length?' open':'')+'">'+(g.sub&&g.sub.length?'▾':'')+'</span>'+
      '<span class="dt-name">'+esc(g.n)+'</span><span class="dt-count">'+esc(String(g.c))+'</span></div>';
    if(g.sub) g.sub.forEach(function(s2){ walk(s2,lv+1); });
  }
  ORG.tree.forEach(function(t){ walk(t,0); });
  return out;
}
function Routes_org(){
  var cols=[
    { label:'姓名',  w:'200', hcl:'', cell:function(m){ return '<span class="tb-badge">'+avatar(m.n)+'</span><span class="tb-2line"><span class="tl">'+esc(m.n)+'</span><span class="ts">'+esc(m.dept)+'</span></span>'; } },
    { label:'部门',  cell:function(m){ return esc(m.dept); } },
    { label:'手机号',cell:function(m){ return '<span class="u-mono">'+esc(m.ph)+'</span>'; } },
    { label:'状态',  cell:function(m){ return m.st==='ok'?'<span class="tag tag--ok">在职</span>':'<span class="tag tag--plain">停用</span>'; } },
    { label:'成员类型',head:'成员类型', cell:function(m){ return '<span class="tag '+ORG.roles[m.role]+'">'+esc(m.role)+'</span>'; } },
    { label:'空间数',w:'76', cell:function(m){ return esc(String(m.sp)); } },
    { label:'最近登录', cell:function(m){ return '<span class="u-faint">'+esc(m.last)+'</span>'; } },
    { label:'', w:'120', head:'操作', cell:function(m){ return '<span class="rest"><button class="t-a link-btn" data-om="menu" data-name="'+esc(m.n)+'">⋯</button></span>'; } }
  ];
  cols.splice(1,1);   // 去重：姓名下已含部门，移除单列部门
  var tbl=H.table(ORG.members,cols,{empty:'无成员'}).outerHTML;
  H.setPage(
    '<div class="a-head"><h1>组织与成员</h1><span class="a-head__sub">演示 mock · 成员真实数据源为后端组织服务；部门目录点击仅为按需 / 演示</span></div>'+
    '<div class="filters" style="margin-top:4px">'+
      '<button class="btn btn--primary" data-om="add">+ 添加成员（钉钉）</button>'+
      '<button class="btn btn--ghost" data-om="sync">从钉钉同步</button><span class="spacer"></span>'+
      '<input class="inp" data-om="kw" style="width:210px;height:30px" placeholder="搜索 姓名 / 部门 / 手机号">'+
      '<select class="sel" data-om="status" style="width:104px;height:30px"><option value="">全部状态</option><option value="ok">在职</option><option value="off">停用</option></select>'+
    '</div>'+
    '<div class="org-cols">'+
      '<div class="dtree-panel panel"><div class="panel__head"><span class="t">组织架构</span><span class="u">'+esc(String(258))+' 人</span></div>'+
        '<div class="dtree-body" data-tree>'+orgTreeHtml()+'</div>'+
        '<div style="padding:10px 14px;border-top:1px solid var(--color-border-light)"><span class="u-faint" style="font-size:12px">提示：真实组织数据来自后端；此处为演示目录导航。</span></div>'+
      '</div>'+
      '<div class="member-body"><div class="member-scroll" data-mwrap>'+tbl+'</div></div>'+
    '</div>', orgBind);
}
function orgBind(){
  var page=pg(),tree=page.querySelector('[data-tree]');
  if(tree) tree.addEventListener('click',function(e){
    var d=e.target.closest?e.target.closest('.dt-row'):null; if(!d)return;
    [].forEach.call(tree.querySelectorAll('.dt-row'),function(x){x.classList.remove('dt-row--on');});
    d.classList.add('dt-row--on');
    if(d.getAttribute('data-leaf')==='1') H.toast('此为按需 / 演示目录：'+(d.getAttribute('data-org')||'')+'（真实数据来自后端组织）');
  });
  orgWireFilters(page);
}
function orgWireFilters(page){
  var kw=page.querySelector('[data-om="kw"]'), st=page.querySelector('[data-om="status"]');
  var run=function(){ orgFilterRows(page); };
  if(kw)kw.addEventListener('input',run);
  if(st)st.addEventListener('change',run);
  page.addEventListener('click',function(e){
    var o=e.target.closest?e.target.closest('[data-om]'):null;
    if(!o)return;
    if(o===kw||o===st)return;
    if(o.closest('[data-tree]'))return;
    orgAct(o.getAttribute('data-om'),o.getAttribute('data-name'),o);
  });
}
function orgFilterRows(page){
  var host=page.querySelector('[data-mwrap] .table-x tbody'); if(!host)return;
  var kw=page.querySelector('[data-om="kw"]').value.trim().toLowerCase();
  var st=page.querySelector('[data-om="status"]').value;
  var trs=host.querySelectorAll('tr');
  ORG.members.forEach(function(m,i){
    var pass=true;
    if(st==='ok'&&m.st!=='ok')pass=false;
    if(st==='off'&&m.st!=='off')pass=false;
    if(pass&&kw&&(m.n+m.dept+m.ph).toLowerCase().indexOf(kw)<0)pass=false;
    if(trs[i])trs[i].style.display=pass?'':'none';
  });
}
function orgMember(name){ var i; for(i=0;i<ORG.members.length;i++)if(ORG.members[i].n===name)return ORG.members[i]; return null; }
function orgAct(v,name){
  if(v==='add'){ H.toast('添加成员（钉钉）：演示将打开钉钉通讯录选择；真实后端从钉钉同步（静态 mock，未持久化）'); return; }
  if(v==='sync'){ H.toast('已触发一次从钉钉同步（演示端点：后端将拉取部门 / 成员增量）'); return; }
  if(v==='menu'){ var m=orgMember(name); if(m)orgMenu(m); }
}
function orgMenu(m){
  var anchor=document.querySelector('[data-om="menu"][data-name="'+esc(m.n)+'"]');
  var r=anchor&&anchor.getBoundingClientRect();
  H.float(Math.min(innerWidth-228,(r?r.right+4:innerWidth-231)),(r?r.bottom+2:innerHeight-180),[
    { icon:IC.book, label:'查看详情', fn:function(){ orgDetail(m); } },
    { icon:IC.x,    label:m.st==='ok'?'停用账户':'启用账户', fn:function(){ orgToggle(m); } },
    { icon:IC.shield,label:'设为部门管理员', fn:function(){ H.toast('原型交互：设定 '+m.n+' 为部门管理员（演示端点，真实按组织角色校验）'); } },
    { sep:1 },
    { icon:IC.key, label:'重置密码', fn:function(){ H.toast('已向 '+m.n+' 发送重置密码指引（演示）'); } },
    { icon:IC.recycle, label:'重置鉴权（密钥类）', danger:true, fn:function(){ orgResetAuth(m); } }
  ]);
}
function orgDetail(m){
  H.drawer({ title:m.n+' · 详情（演示）', body:
    '<div style="display:flex;align-items:center;gap:12px;margin-bottom:6px">'+avatar(m.n)+
      '<div><div style="font-weight:600">'+esc(m.n)+'</div><div class="u-faint" style="font-size:12px">'+esc(m.dept)+' · '+esc(m.role)+'</div></div></div>'+
    H.kv({ '部门':esc(m.dept),'成员类型':esc(m.role),'手机号':esc(m.ph),
      '在职状态':m.st==='ok'?'在职':'停用','所属空间数':String(m.sp),'最近登录':esc(m.last),
      '说明':'演示性基础信息；真实账号 / 任职 / 角色归属以后端组织为准。' }) });
}
function orgToggle(m){
  if(m.st==='off'){ m.st='ok'; Routes_org(); H.toast('已启用 '+m.n+' 的账户（演示）'); return; }
  H.confirm('停用账户',
    '确认停用 <b>'+esc(m.n)+'</b>？<br><br>账户停用后，其已有 JWT token（含已在多端登录的会话）立即失效；'+
    '该成员在各空间的成员关系不会据此解除，也不影响同空间中其他成员的权限（成员关系为独立维度）。<br><br>属演示危险操作，需再次确认。',
    function(){ m.st='off'; Routes_org(); H.toast('账户 '+m.n+' 已停用（演示），其 token 随即失效'); },
    { kicker:'停用账户 · 涉及访问安全' });
}
function orgResetAuth(m){
  H.confirm('重置鉴权（密钥）',
    '将吊销 '+esc(m.n)+' 当前会话鉴权材料并重新发放密钥；重置后其既有 JWT token 立即失效。<br>属演示危险操作，需再次确认。',
    function(){ H.toast('已重置 '+m.n+' 的鉴权与密钥（演示）；既有 token 已失效'); },
    { kicker:'重置鉴权 · 涉及访问安全' });
}
Routes['org']=function(){ Routes_org(); };

/* ============ 3) spaces · 空间管理 ============ */
var SPACES=[
  { n:'张研个人盘',           k:'PERSONAL',     owner:'张研 个人', mb:1,  used:512,  rev:0,   q:2000, st:'on',  ct:'09/04 10:12' },
  { n:'研发部-产品资料',      k:'FOLDER-DRIVE', owner:'研发部',    mb:18, used:2430, rev:200, q:5100, st:'on',  ct:'08/12 14:23' },
  { n:'生产部-图纸',          k:'FOLDER-DRIVE', owner:'生产部',    mb:9,  used:1716, rev:410, q:5175, st:'on',  ct:'07/30 09:31' },
  { n:'管理中心-文件',        k:'FOLDER-DRIVE', owner:'管理中心',  mb:6,  used:1220, rev:120, q:3000, st:'on',  ct:'06/19 16:05' },
  { n:'销售部 镜像盘',        k:'FOLDER-DRIVE', owner:'销售部',    mb:0,  used:0,    rev:0,   q:1000, st:'off', ct:'05/11 11:08' },
  { n:'生产部-临时图纸转储',  k:'FOLDER-DRIVE', owner:'生产部',    mb:2,  used:4120, rev:90,  q:4100, st:'on',  ct:'09/01 08:52', over:true }
];
/*  本表有：个人盘 1(张研) · 部门盘 4 · 停用 1(销售部镜像盘) · 超配额 danger 1(最后一条) */
function drvBlock(s){
  var usedC=Math.min(s.used/s.q*100,100);
  var availW=Math.max(100-usedC,0);
  var revC=Math.min(s.rev/s.q*100,availW);
  var ov=Math.max(s.used-s.q,0), ovC=ov>0?Math.min(ov/s.q*100,100):0;
  var bar='<span class="dq-bar">'+(s.used?'<i class="bu" style="width:'+usedC.toFixed(1)+'%"></i>':'')+
    (s.rev?'<i class="br" style="width:'+revC.toFixed(1)+'%"></i>':'')+
    (ovC?'<i class="dq-over" style="width:'+ovC.toFixed(1)+'%"></i>':'')+'</span>';
  var cap=s.used>=s.q?'<span style="color:var(--danger);font-weight:600">'+esc(H.gb(s.used))+'</span>':esc(H.gb(s.used));
  cap+=(s.rev?' <span class="u-faint">+'+esc(H.gb(s.rev))+' 预留</span>':'')+' / '+esc(H.gb(s.q));
  return bar+'<span class="x-nums" style="display:block;margin-top:4px">'+cap+'</span>';
}
function Routes_spaces(){
  var cols=[
    { label:'空间名',  w:'240', cell:function(s){ return '<span class="tb-badge">'+ic(s.k==='PERSONAL'?IC.book:IC.recycle)+
        '<span class="tb-2line"><span class="tl">'+esc(s.n)+'</span><span class="ts u-faint">'+esc(s.k==='PERSONAL'?'个人盘':'部门盘')+'</span></span></span>'; } },
    { label:'类型',    cell:function(s){ return H.tag(s.k); } },
    { label:'owner',   cell:function(s){ return esc(s.owner)+(s.k==='FOLDER-DRIVE'?'<span class="u-faint" style="font-size:12px">（部门）</span>':''); } },
    { label:'成员数', w:'80',  cell:function(s){ return esc(String(s.mb)+' 人'); } },
    { label:'容量 / 配额', cell:function(s){ return drvBlock(s); } },
    { label:'状态',    cell:function(s){ return s.st==='on'?'<span class="tag tag--ok">启用</span>':'<span class="tag tag--warn">停用</span>'; } },
    { label:'创建时间',cell:function(s){ return '<span class="u-faint">'+esc(s.ct)+'</span>'; } },
    { label:'', w:'130',head:'操作', cell:function(s){ return '<span class="rest"><button class="t-a link-btn" data-sm="menu" data-i="'+SPACES.indexOf(s)+'">⋯</button></span>'; } }
  ];
  var tbl=H.table(SPACES,cols,{empty:'尚未创建空间'}).outerHTML;
  H.setPage(
    '<div class="a-head"><h1>空间管理</h1><span class="a-head__sub">演示 mock · 新建 / 停用仅做本地行更新（不持久化），刷新复位；改数据即改 SPACES 数组</span></div>'+
    '<div class="filters" style="margin-top:4px">'+
      '<button class="btn btn--primary" data-sm="new">+ 新建空间</button>'+
      '<select class="sel" data-sm="kind" style="width:120px;height:30px"><option value="">全部类型</option><option value="PERSONAL">个人盘</option><option value="FOLDER-DRIVE">部门盘</option></select>'+
      '<select class="sel" data-sm="stsel" style="width:116px;height:30px"><option value="">全部状态</option><option value="on">启用</option><option value="off">停用</option></select>'+
      '<span class="spacer"></span><span class="result">共 '+esc(String(SPACES.length))+' 个空间</span>'+
    '</div>'+
    '<div class="member-body"><div style="overflow:auto;flex:1" data-swrap>'+tbl+'</div></div>', spacesBind);
}
Routes['spaces']=Routes_spaces;
function spacesBind(){
  var page=pg();
  var kind=page.querySelector('[data-sm="kind"]'), stsel=page.querySelector('[data-sm="stsel"]');
  var ref=function(){ var kv=kind&&kind.value, sv=stsel&&stsel.value; return {kv:kv,sv:sv}; };
  function applyF(){
    var wrap=page.querySelector('[data-swrap] table tbody'); if(!wrap)return;
    var o=ref();
    var trs=wrap.querySelectorAll('tr');
    SPACES.forEach(function(s,i){ var pass=true;
      if(o.kv&&s.k!==o.kv)pass=false;
      if(o.sv&&s.st!==o.sv)pass=false;
      if(trs[i])trs[i].style.display=pass?'':'none';
    });
  }
  if(kind)kind.addEventListener('change',applyF);
  if(stsel)stsel.addEventListener('change',applyF);
  page.addEventListener('click',function(e){
    var o=e.target.closest?e.target.closest('[data-sm]'):null; if(!o)return;
    if(o===kind||o===stsel)return;
    var v=o.getAttribute('data-sm');
    if(v==='new')return spacesNewDlg(page);
    if(v==='menu'){ var s=SPACES[+o.getAttribute('data-i')]; if(s)spacesMenu(s,o); }
  });
}
function spacesMenu(s,node){
  var r=node.getBoundingClientRect();
  H.float(Math.min(innerWidth-230,(r.right+4)),(r.bottom+2),
    s.st==='on'
    ?[
      { icon:IC.book, label:'查看详情', fn:function(){ spacesDrawer(s); } },
      { icon:IC.key,  label:'查看配额', fn:function(){ quotaDrawer(s); } },
      { icon:IC.x,    label:'停用空间', fn:function(){ spacesToggle(s); } },
      { sep:1 },
      { icon:IC.recycle, label:'转交 owner', danger:true, fn:function(){ spacesTransfer(s); } }
    ]
    :[
      { icon:IC.book, label:'查看详情', fn:function(){ spacesDrawer(s); } },
      { icon:IC.key,  label:'查看配额', fn:function(){ quotaDrawer(s); } },
      { icon:IC.shield,label:'重新启用', fn:function(){ spacesToggle(s); } },
      { sep:1 },
      { icon:IC.recycle, label:'转交 owner', danger:true, fn:function(){ spacesTransfer(s); } }
    ]);
}
function spacesToggle(s){
  var on=s.st==='on';
  var label=on?'停用空间':'启用空间';
  function doIt(){ s.st=on?'off':'on'; Routes_spaces(); H.toast(label+'：'+(s.n)+'（演示）'+(on?'，将拒绝新建写入并结束在线会话':'，恢复访问')); }
  if(on) H.confirm(label,'确认停用空间 <b>'+esc(s.n)+'</b>？停用后成员仍保留成员关系，但将不能新建 / 上传。<br><br>属演示危险操作，请再次确认。',doIt,{ kicker:'停用空间 · 影响写入与会话' });
  else doIt();
}
function spacesTransfer(s){
  H.confirm('转交 owner',
    '将空间 <b>'+esc(s.n)+'</b> 的所有者转交给其它成员。<br>仅平台管理员可执行此类移交；真实流程需在选择新 owner 后二次确认方可生效。<br><br>属演示危险操作，请再次确认。',
    function(){ H.toast('已发起空间 '+s.n+' 的 owner 转交（演示：需选择新 owner 后二次确认，此处仅示意）'); },
    { kicker:'转交 owner（危险） · 仅平台管理员可执行' });
}
function spacesDrawer(s){
  var head='<div style="display:flex;align-items:center;gap:10px;margin-bottom:8px">'+
    ic(s.k==='PERSONAL'?IC.book:IC.recycle)+
    '<div><div style="font-weight:600">'+esc(s.n)+'</div><span class="tag '+(s.st==='on'?'tag--ok':'tag--warn')+'">'+(s.st==='on'?'启用':'停用')+'</span></div></div>';
  H.drawer({ title:'空间 · 概览（演示）', body:
    head+H.kv({
      '空间名':esc(s.n),
      '类型':s.k==='PERSONAL'?'个人盘':'部门盘',
      'owner':esc(s.owner)+(s.k==='FOLDER-DRIVE'?'（部门盘 · owner 归属部门）':''),
      '成员数':String(s.mb),
      '创建时间':esc(s.ct),
      '说明':'演示性基础信息。个人盘 owner 的密码 / 配置密钥属于账号 profile（此处不展示）；以真实后端为准。'
    }) });
}
function quotaDrawer(s){
  var usedP=s.used/s.q*100;
  H.drawer({ title:s.n+' · 配额（演示）', body:
    '<div>'+drvBlock(s)+'</div>'+
    '<div class="perm-detail" style="margin-top:10px">配额总量 <b>'+esc(H.gb(s.q))+'</b>；已用 '+esc(H.gb(s.used))+
    '（约占配额 '+usedP.toFixed(1)+'%）'+(s.rev?'；其中保留预留 '+esc(H.gb(s.rev))+'':'')+
    (s.used>s.q?'。<span style="color:var(--danger)">当前已超配额，需人工扩容或清理。</span>':'。')+
    '<br><br>配额在演示中均为本地采样数值，可调整上方 SPACES 数据刷新显示。</div>' });
}
function spacesNewDlg(page){
  var type='FOLDER-DRIVE';
  var form='<div class="dlg-form">'+
    H.formRow('空间类型','<select class="sel" id="nsType">'+
      '<option value="FOLDER-DRIVE">部门盘</option><option value="PERSONAL">个人盘</option></select>')+
    H.formRow('空间名称','<input class="inp" id="nsName" placeholder="例如：研发部-对外资料" value="">')+
    H.formRow('所属 / owner','<select class="sel" id="nsOwner">'+
      '<option value="研发部">研发部</option><option value="生产部">生产部</option><option value="管理中心">管理中心</option><option value="销售部">销售部</option><option value="张研">张研（个人）</option></select>')+
    H.formRow('初始配额','<select class="sel" id="nsQuota">'+
      '<option value="200">200 GB</option><option value="500">500 GB</option><option value="1000">1000 GB</option><option value="2000">2000 GB</option></select>')+
    '<div class="dialog__msg" style="margin:2px 0 0;padding:0"><span class="u-faint" style="font-size:12px">个人盘将自动绑定选中用户；此处视为演示操作，数据不做持久化，仅本地追加。</span></div></div>';
  var d=H.dialog({ title:'新建空间',
    msg:'选择空间类型后按需补全名称与配额。',
    form:form,
    actions:'<button class="btn btn--ghost" data-act="no">取消</button><button class="btn btn--primary" data-act="ok">创建空间</button>',
    onOk:function(){
      var scope=d.scope||document;
      var t=scope.querySelector('#nsType').value;
      var nm=scope.querySelector('#nsName').value.trim();
      var ow=scope.querySelector('#nsOwner').value;
      var q=+scope.querySelector('#nsQuota').value;
      if(!nm){ H.toast('请填写空间名称'); return false; }
      var now=new Date();var pad=function(x){return x<10?'0'+x:x;};
      var ct=pad(now.getMonth()+1)+'/'+pad(now.getDate())+' '+pad(now.getHours())+':'+pad(now.getMinutes());
      // 类型若为个人盘则绑定所选用户 id —— 运维抽样演示，按展示层面记录
      var ownerLabel=(t==='PERSONAL'?(ow+'（个人）'):(ow==='张研'?ow+'（个人）':ow));
      SPACES.unshift({ n:nm, k:t, owner:ownerLabel, mb:t==='PERSONAL'?1:0, used:0, rev:0, q:q, st:'on', ct:ct });
      Routes_spaces();
      H.toast('已初始化空间：'+nm+'（演示态，未持久化到后端）');
      return false;   // 已自行刷新，关闭由 ok 调用侧再关
    }
  });
  // 类型切换联动可见性保持简单：暂不做显示层隐藏，owner 选择即广义 owner
}
/* ============ 4) perms · 空间成员权限（管理员核心） ============ */
var PERM={
  scopes:[ '研发部-产品资料（部门盘）','生产部-图纸（部门盘）','管理中心-文件（部门盘）','销售部 镜像盘（部门盘）' ],
  scopeIdx:0,
  caps:[
    { k:'DRIVE_READ',    name:'浏览',       dep:null,     lock:true },
    { k:'FILE_PREVIEW',  name:'预览',       dep:['DRIVE_READ'], lock:false },
    { k:'FILE_DOWNLOAD', name:'下载',       dep:['FILE_PREVIEW'], lock:false },
    { k:'FILE_CREATE',   name:'上传 / 新建', dep:['DRIVE_READ'], lock:false },
    { k:'FILE_WRITE',    name:'重命名 / 编辑', dep:['FILE_CREATE'], lock:false },
    { k:'FILE_MOVE_COPY',name:'移动 / 复制', dep:['FILE_CREATE'], lock:false },
    { k:'FILE_DELETE',   name:'删除',       dep:['FILE_CREATE'], lock:false }
  ],
  presets:[
    { label:'仅查看',     h:null,  set:['DRIVE_READ'] },
    { label:'浏览+预览+下载', h:'基础能力', set:['DRIVE_READ','FILE_PREVIEW','FILE_DOWNLOAD'] },
    { label:'协作者（读写）', h:'协作',     set:['DRIVE_READ','FILE_PREVIEW','FILE_DOWNLOAD','FILE_CREATE','FILE_WRITE','FILE_MOVE_COPY'] },
    { label:'内容全权（可删）', h:'全权',   set:['DRIVE_READ','FILE_PREVIEW','FILE_DOWNLOAD','FILE_CREATE','FILE_WRITE','FILE_MOVE_COPY','FILE_DELETE'] }
  ],
  members:[
    { name:'张研', dept:'平台管理员 · 研发部', perms:['MANAGE'], meta:'空间管理者（owner）', editable:false },
    { name:'王磊', dept:'部门管理员 · 研发部', perms:['DRIVE_READ','FILE_PREVIEW','FILE_DOWNLOAD','FILE_CREATE','FILE_WRITE','FILE_MOVE_COPY','FILE_DELETE'], meta:'协作者' },
    { name:'周敏', dept:'部门盘 owner · 研发部', perms:['DRIVE_READ','FILE_PREVIEW','FILE_DOWNLOAD','FILE_CREATE','FILE_WRITE','FILE_MOVE_COPY','FILE_DELETE'], meta:'owner', isOwner:true },
    { name:'李明', dept:'成员 · 研发部', perms:['DRIVE_READ'], meta:'仅查看（用户无预览）', readOnlyLock:true }
  ],
  order:['DRIVE_READ','FILE_PREVIEW','FILE_DOWNLOAD','FILE_CREATE','FILE_WRITE','FILE_MOVE_COPY','FILE_DELETE']
};
var PERM_CUR=null;
function permPresetBtn(){}
function Routes_perms(){
  renderPerm(0);
}
Routes['perms']=Routes_perms;
function permChipClass(set){
  // 单一语义标注：仅查看 / 只读等，实际能力集合体由编辑器勾选呈现
  return '';
}
function permSel(i){ PERM_CUR=i; renderPerm(i); }
function permNote(list){
  return list.join('、');
}
function memberBadge(m){
  if(m.isOwner)return '<span class="tag tag--primary">owner</span>';
  if(m.dept.indexOf('平台管理员')>=0)return '<span class="tag tag--danger">空间管理者</span>';
  if(m.readOnlyLock)return '<span class="tag tag--warn">仅查看</span>';
  return '<span class="tag tag--plain">成员</span>';
}
function renderPerm(active){
  var m=PERM.members[active==null?0:active];
  PERM_CUR=PERM.members.indexOf(m);
  var list='<div class="ofilter"><input class="inp" data-p="q" placeholder="搜索成员姓名" style="width:100%"></div>'+
    '<div data-p="who">';
  PERM.members.forEach(function(mm,i){
    list+='<button class="mem-item'+(i===PERM_CUR?' mem-item--on':'')+'" data-p="pick" data-i="'+i+'" style="width:auto;display:flex">'+
      avatar(mm.name)+'<span class="mem-body"><span class="mn">'+esc(mm.name)+memberBadge(mm)+'</span>'+
      '<span class="ms">'+esc(mm.dept)+'</span></span></button>';
  });
  list+='</div>';
  var editor=permEditor(m);
  H.setPage(
    '<div class="a-head"><h1>空间成员权限</h1><span class="a-head__sub">按 5.5 精确能力集 · 演示 mock；保存即 toast，多端刷新不影响说明</span></div>'+
    '<div class="filters" style="margin-top:4px">'+
      '<span class="fl">范围</span>'+
      '<select class="sel" data-p="scope" style="width:250px">'+PERM.scopes.map(function(s,i){return '<option'+(i===0?' selected':'')+'>'+esc(s)+'</option>';}).join('')+'</select>'+
      '<span class="spacer"></span><button class="btn btn--ghost" data-p="batch">批量设置…</button>'+
    '</div>'+
    '<div class="perm-cols">'+
      '<div class="dtree-panel panel perm-list-holder"><div class="panel__head"><span class="t">成员</span><span class="u">'+esc(String(PERM.members.length))+'</span></div>'+
        '<div class="perm-list-holder" data-p="host">'+list+'</div></div>'+
      '<div class="panel perm-editor" data-p="ed">'+editor+'</div>'+
    '</div>', permBind);
}
function capRow(c,m){
  // 浏览始终锁定勾选不可去勾(DRIVE_READ)；携依赖与禁组合校验
  var locked = (c.lock && m.readOnlyLock) || (c.k==='DRIVE_READ');
  var checked = hasCap(m,c.k);
  var forb=false,tip='';
  if(c.k==='FILE_PREVIEW' && !hasCap(m,'DRIVE_READ')){ forb=true; tip='需先具备「浏览」'; }
  if(c.k==='FILE_DOWNLOAD'){
    if(!hasCap(m,'FILE_PREVIEW')){ forb=true; tip='需先具备「预览」依赖后可选'; }
    else if(!hasCap(m,'DRIVE_READ')){ forb=true; }
  }
  if(/CREATE|WRITE|MOVE_COPY|DELETE/.test(c.k) && !hasCap(m,'DRIVE_READ')){ forb=true; tip='需先具备「浏览」'; }
  var disable=(c.k!=='DRIVE_READ'&&c.k!=='FILE_PREVIEW')&&false; // 单独预览需浏览
  // 单元级即时禁选表达：
  var canChk=true;
  if(c.k==='FILE_PREVIEW'&&!hasCap(m,'DRIVE_READ')){canChk=false;}
  if(c.k==='FILE_DOWNLOAD'&&!hasCap(m,'FILE_PREVIEW')){canChk=false;}
  if(c.k==='FILE_CREATE'&&!hasCap(m,'DRIVE_READ')){canChk=false;}
  if(c.k==='FILE_WRITE'/*需上传*/&&!hasCap(m,'FILE_CREATE')){canChk=false;}
  if(c.k==='FILE_MOVE_COPY'&&!hasCap(m,'FILE_CREATE')){canChk=false;}
  if(c.k==='FILE_DELETE'&&!hasCap(m,'FILE_CREATE')){canChk=false;}
  var reallyLock=m.isOwner||m.readOnlyLock||(m.perms&&m.perms.indexOf('MANAGE')>=0);
  var editOk=c.k==='DRIVE_READ'||(!m.isOwner&&!m.readOnlyLock&&c.k!=='MANAGE');
  var allowRow=canChk&&editOk;
  var chkRows='<input type="checkbox" class="chk" data-p="cap" data-k="'+c.k+'"'+(checked?' checked':'')+
    (allowRow?'':' disabled')+">";
  if(!editOk&&c.k!=='DRIVE_READ')chkRows+='<span class="locked-tip" style="display:inline-flex;font-size:11px;color:var(--text-3);margin-left:6px">只读</span>';
  var sub=(c.dep&&c.dep.length?' <span class="u-faint" style="font-size:11px">依赖：'+c.dep.map(function(d){return d==='DRIVE_READ'?'浏览':'上传' ;}).join('、')+'</span>':'');
  return '<div class="capability'+(canChk&&c.k!=='DRIVE_READ'?' can-c':'')+'" '+(locked&&canChk?'':'')+'>'+
    '<div class="cap-left"><span class="cap-title">'+esc(c.name)+sub+'</span></div>'+
    (c.k==='DRIVE_READ'?'<span class="tag tag--plain" style="margin-left:8px">锁定启用</span>':'')+
    '<span class="cap-check">'+chkRows+(canChk?'':('<span class="u-faint" style="font-size:11px;margin-left:6px">'+(c.k==='FILE_PREVIEW'?'需浏览':(c.k==='FILE_DOWNLOAD'?'需预览':'需浏览'))+'</span>'))+'</span></div>';
}
function hasCap(m,k){ return !!(m.perms&&m.perms.indexOf(k)>=0); }
function permEditor(m){
  var preset='<span class="lbl">快捷预设</span>';
  PERM.presets.forEach(function(p){ preset+='<button class="preset" data-p="preset" data-set="'+esc(p.set.join(','))+'">'+esc(p.label)+'</button>'; });
  var scopeName='范围：'+esc(PERM.scopes[PERM.scopeIdx]||'部门盘·研发部');
  var rows=PERM.order.map(function(k,i){ return capRow(PERM.caps[i],m); }).join('');
  var header=
    '<div style="display:flex;align-items:center;gap:8px;flex:none;padding:12px 16px;border-bottom:1px solid var(--color-border-light)">'+
    avatar(m.name)+
    '<div style="min-width:0;flex:1"><div style="font-weight:600;display:flex;align-items:center;gap:8px;flex-wrap:wrap">'+esc(m.name)+memberBadge(m)+'</div>'+
    '<div class="u-faint" style="font-size:12px">'+esc(m.dept||'')+'</div></div>'+
    '<span class="u-faint" style="font-size:12px;white-space:nowrap">'+scopeName+'</span></div>';
  var readOnlyTip=(m.readOnlyLock)?('<div class="ped-foot" style="border:0;border-bottom:1px solid var(--color-border-light);justify-content:flex-start;padding:8px 16px"><span class="tag tag--warn" style="margin-right:6px">仅查看</span><span class="u-faint" style="font-size:12px">细粒度只读：该成员当前仅被授予浏览（DRIVE_READ），无写能力。</span></div>'):'';
  var mgr=m.isOwner||(m.perms&&m.perms.indexOf('MANAGE')>=0&&!m.editable);
  var canLeave=(m.isOwner||m.perms&&m.perms.indexOf('MANAGE')>=0)&&!m.isOwner===false;
  var danger='';
  if(m.isOwner||m.perms&&m.perms.indexOf('MANAGE')>=0&&!m.editable){
    var ownerBox=m.isOwner;
    var chkMAN= ownerBox
      ? '<span class="tag tag--plain">MANAGE 对 owner 恒置开</span>'
      : '<label style="display:inline-flex;align-items:center;gap:6px;font-size:12px"><input type="checkbox" class="chk" data-p="mgr" checked>空间管理（MANAGE）</label>';
    danger='<div class="ped-danger" style="padding:12px 14px;margin:8px 16px 12px">'+
      '<div style="display:flex;justify-content:space-between;gap:10px;align-items:flex-start;flex-wrap:wrap">'+
      '<div><div class="pd-t">空间管理者 / owner 区</div>'+
      '<div style="font-size:12px;color:var(--text-2);max-width:300px">'+(ownerBox?'当前用户为本空间 owner，MANAGE 由对象属性决定，不能被降为纯只读；如需降级应先移交 owner。':'空间管理者：可被移出本空间，MANAGE 表示对成员与对象的治理级能力。')+'</div></div>'+
      '<div style="display:flex;align-items:center;gap:8px;flex:none">'+chkMAN+
      '<button class="btn btn--danger-text btn--small" data-p="rm"'+((m.isOwner)?' disabled':'')+'>移出空间</button>'+
      '<button class="link-btn" style="color:var(--danger)" data-p="transfer">移交 owner</button>'+
      '</div></div></div>';
  }
  return '<div class="ped-head" style="flex-direction:column;padding:0;border-bottom:1px solid var(--color-border-light)">'+header+
    '<div style="padding:4px 16px 10px">'+preset+'</div></div>'+
    '<div class="ped-body">'+readOnlyTip+
    '<div class="perm-group__t" style="padding:8px 16px;margin:0">内容能力集 · 精确到能力点</div>'+rows+
    (danger||'')+'</div>'+
    '<div class="ped-foot"><span class="u-faint" style="font-size:12px;line-height:1.5">显式保存：保存后权限即时生效，不随 token 缓存。</span><span class="spacer" style="flex:1"></span>'+
    '<button class="btn btn--ghost btn--small" data-p="cancel">取消（回默认）</button>'+
    '<button class="btn btn--primary btn--small" data-p="save">保存权限</button></div>';
}
var PlatformAdmin=true;              // 演示上下文：当前登录平台管理员

var PERM_ACV=null;                    // 当前激活成员引用（重绘以它为准）
function hasC(m,k){ return (m.perms||[]).indexOf(k)>=0; }
function capDepsK(k){ var c=_craw(k); return c? (c.dep||[]) : []; }
function capImmediateDep(k){ var c=_craw(k); return c&&c.dep&&c.dep[0]||'DRIVE_READ'; }
function _craw(k){ var i; for(i=0;i<PERM.caps.length;i++)if(PERM.caps[i].k===k)return PERM.caps[i]; return null; }

/* 保证能力组合一致：勾选时自动补齐祖先；取消时级联取消其下级能力的祖先缺失者 */
function permInvariants(m,forceBrowse){
  var set=m.perms||(m.perms=[]);
  set.sort(function(a,b){ return PERM.order.indexOf(b)-PERM.order.indexOf(a); });
  set=set.filter(function(k){ return k==='MANAGE'||PERM.order.indexOf(k)>=0; });
  // 若拥有写/预览却不含浏览，则默认其本来自带 Browse（浏览恒为基底）
  var hasBrowse=set.indexOf('DRIVE_READ')>=0;
  var hasWrite=set.some(function(k){ return /PREVIEW|DOWNLOAD|CREATE|WRITE|MOVE|DELETE/.test(k)&&k!=='MANAGE'; });
  if(hasWrite&&!hasBrowse){ set.push('DRIVE_READ'); hasBrowse=true; }
  // 补齐缺失祖先（下载依赖预览 → 预览依赖浏览）
  function need(k){ return k!=='DRIVE_READ'&&k!=='MANAGE'?_craw(k):null; }
  var grew=true; var g=0;
  while(grew&&g<8){ grew=false; g++;
    set.slice().forEach(function(k){
      var c=need(k); if(!c)return;
      (c.dep||[]).forEach(function(p){ if(set.indexOf(p)<0&&p!=='MANAGE'){ set.push(p); if(p==='DRIVE_READ'||/_CREATE|WRITE|MOVE|DELETE|DOWNLOAD|PREVIEW/.test(p)){} grew=true; } });
    });
  }
  // 从不含祖先 = 浏览的空集成员开（防止孤点）
  set=set.filter(function(k){ return k==='MANAGE'||hasBrowse||k==='DRIVE_READ'; });
  if(forceBrowse){ // readOnly 强制最小集
    var mo=set.indexOf('MANAGE')>=0;
    m.perms = ['DRIVE_READ'].concat(mo?['MANAGE']:[]);
  } else {
    m.perms=set;
  }
  return m;
}
function permDraftFor(m){
  // 可撤销：m 上直接改，取消走从 PERM 初始 build 数据重新生成成员对象? 直接改意味着取消无法还原，
  // 故取消/切换保留一份 baseline（在 PERM.members 对象内）由 guard: 我们用 permRaw 存副本。
  return m;
}
function flipCapFor(m,k,on){
  var locked=(m.isOwner)||(m.readOnlyLock)||(m.perms&&m.perms.indexOf('MANAGE')>=0&&k!=='MANAGE');
  var mgrOnly=k!=='MANAGE';
  if((m.readOnlyLock&&k!=='DRIVE_READ'&&k!=='MANAGE')||(m.isOwner)){ return {proceed:false,msg:'该成员为锁定 / owner，仅查看。'}; }
  if(k==='DRIVE_READ')on=true;   // 浏览锁定常开
  var i=m.perms.indexOf(k);
  if(on&&i<0)m.perms.push(k);
  if(!on&&i>=0)m.perms.splice(i,1);
  permInvariants(m,m.readOnlyLock);
  return {proceed:true};
}
function applyPreset(m,set,onLocked){
  if(m.isOwner||m.readOnlyLock) return {proceed:false,msg:'锁定 / owner 成员不支持快捷预设'};
  m.perms=set.slice();
  if(m.perms.indexOf('MANAGE')<0 && (m.meta&&/管理|治理/.test(m.meta)) ) { /* 管理者MANAGE独立于内容，由系统决定 */ }
  permInvariants(m,false);
  return {proceed:true};
}
/* perms 页交互 */
function permBind(){
  var page=pg();
  var q=page.querySelector('[data-p="q"]');
  page.addEventListener('click',function(e){
    var t=e.target;
    var pick=t.closest?t.closest('[data-p="pick"]'):null;
    if(pick){ var i=+pick.getAttribute('data-i'); permEdit(i); return; }
    var pre=t.closest?t.closest('[data-p="preset"]'):null;
    if(pre){ var m=PERM.members[activeIdx()]; var set=(pre.getAttribute('data-set')||'').split(',').filter(Boolean).concat((m.perms||[]).indexOf('MANAGE')>=0?['MANAGE']:[]);
      var r=applyPreset(m,unique(set),!!m.readOnlyLock);
      if(!r.proceed){ H.toast(r.msg); return; } renderPerm(activeIdx()); return; }
    if((t.closest&&t.closest('[data-p="save"]'))){ var mm=PERM.members[activeIdx()]; H.toast('已保存 '+mm.name+' 的权限（演示：随 token 缓存即时生效）'); return; }
    if((t.closest&&t.closest('[data-p="cancel"]'))){ permReset(activeIdx()); return; }
    var transfer=t.closest&&t.closest('[data-p="transfer"]'); if(transfer){ permTransfer(); return; }
    var rm=t.closest&&t.closest('[data-p="rm"]'); if(rm){ permRemoveM(); return; }
    var batch=t.closest&&t.closest('[data-p="batch"]'); if(batch){ H.toast('批量设置：演示将对本范围全体成员按所选策略覆盖设置（此处仅示意）'); return; }
    var mgr=t.closest&&t.closest('[data-p="mgr"]'); if(mgr){ H.toast('MANAGE 为治理级，由成员角色决定，此处演示不修改'); }
  });
  page.addEventListener('change',function(e){
    var t=e.target;
    if(t&&t.hasAttribute&&t.hasAttribute('data-p')&&t.getAttribute('data-p')==='cap'){
      var mm=PERM.members[activeIdx()];
      var k=t.getAttribute('data-k'), on=t.checked;
      var r=flipCapFor(mm,k,on);
      if(!r.proceed){ if(!on){t.checked=true;} H.toast(r.msg); return; }
      // 依赖缺失即时自动打勾提示
      var needAll=(_anc(k)||[]).filter(function(x){return !hasC(mm,x);});
      renderPerm(activeIdx());
      if(!on&&needAll.length)H.toast('已取消 '+_craw(k).name+'：将不会自动影响下游（浏览保持常开）');
      // H.toast(...) empty path leaks none
    }
  });
  if(q)q.addEventListener('input',function(){
    var mwrap=page.querySelector('[data-perm-list]') || page.querySelector('[data-p="host"]');
    var kw=(q.value||'').trim().toLowerCase();
    if(!mwrap)return;
    [].forEach.call(mwrap.querySelectorAll('[data-p="pick"]'),function(row){
      var idx=+row.getAttribute('data-i'); var m=PERM.members[idx]; if(!m)return;
      row.style.display=(!kw||(m.name+m.dept+m.meta||'').toLowerCase().indexOf(kw)>=0)?'':'none';
    });
  });
}
function _anc(k){ // 递归祖先（不含自身）
  var out=[],vis={};
  function walk(x){ var c=_craw(x); if(!c)return; (c.dep||[]).forEach(function(p){ if(!vis[p]){vis[p]=1;out.push(p);walk(p);} }); }
  walk(k); return out;
}
function activeIdx(){ return PERM_ACV==null?0:PERM.members.indexOf(PERM_ACV); }
function permEdit(i){ PERM.members[i] && (PERM_ACV=PERM.members[i]); renderPerm(PERM.members.indexOf(PERM_ACV)); }
function permReset(i){ var m=PERM.members[i]; if(!m)return; /* 复位：用元数据 build 还原 */ if(m._seed){ m.perms=m._seed.slice(); } renderPerm(i); }
function permSeeds(){ PERM.members.forEach(function(m){ m._seed=(m.perms||[]).slice(); }); }
permSeeds();
function permTransfer(){ H.confirm('移交 owner','请先在成员中选择新 owner；真实流程需二次确认后生效。<br>属演示危险操作，请再次确认。',function(){ H.toast('已发起 owner 移交（需在确认弹窗点击二次确认；此处仅演示重绘态）'); },{ kicker:'移交 owner · 仅平台管理员可执行' }); }
function permRemoveM(){ var i=activeIdx(); if(permAvi(i)){} H.confirm('移出空间','确认将该成员移出本空间？成员关系为独立维度，移出后其访问随之失效。<br>属演示危险操作，请再次确认。',function(){ H.toast('演示：已移出 '+PERM.members[i].name+'（真实为显式删除关系，此处静态 mock 不生效）'); },{ kicker:'移出空间成员' }); }
function permAvi(i){ return true; }
function unique(a){ return a.filter(function(x,i){ return a.indexOf(x)===i; }); }
/*__APPEND__*/
})();










