/* ================================================================
   admin-core.js —— 管理端公共内核
   依赖 ui-base.css（视觉冻结）；仅含共享工具/遮罩层/表格等。
   页面组装见：admin-pages-ops.js g = 运营与治理, admin-pages-sys.js = 审计与配置
   ================================================================ */
(function(){
'use strict';

var root;
function el(id){ return document.getElementById(id); }

function esc(s){
  return String(s==null?'':s)
    .replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')
    .replace(/"/g,'&quot;').replace(/'/g,'&#39;');
}
/* 内联线性图标（统一 20 网格 · 描边 1.5 · currentColor） */
function svg(svg){
  return '<svg viewBox="0 0 20 20" width="16" height="16" aria-hidden="true">'+
    svg.replace(/stroke-width=(['"])(\d)/g,'stroke-width="1.5"')+'</svg>';
}
var IC={
  up:'<path d="M10 15V5M6 7.5 10 3.5l4 4" fill="none" stroke="currentColor"/><path d="M3.5 16.5h13" stroke="currentColor"/>', /* 缺更好的线性上传 */
  plus:'<path d="M10 4v12M4 10h12" fill="none" stroke="currentColor"/>',
  filter:'<path d="M3 5.5h14M5.5 10h9M8.5 14.5h3" fill="none" stroke="currentColor"/>',
  more:'<circle cx="5" cy="10" r="1.2" fill="currentColor"/><circle cx="10" cy="10" r="1.2" fill="currentColor"/><circle cx="15" cy="10" r="1.2" fill="currentColor"/>',
  close:'<path d="M5 5l10 10M15 5 5 15" fill="none" stroke="currentColor"/>',
  chk:'<path d="M4 10.5l3.5 3.5L16 6.5" fill="none" stroke="currentColor"/>',
  warn:'<path d="M10 3.5 17.5 16h-15Z" fill="none" stroke="currentColor" stroke-linejoin="round"/><path d="M10 8v4M10 14.2v.1" stroke="currentColor" stroke-linecap="round"/>',
  x:'<path d="M5.5 5.5h9M14.5 6l-1 9a1 1 0 0 1-1 .8H7.5a1 1 0 0 1-1-.8l-1-9" fill="none" stroke="currentColor"/>',
  edit:'<path d="M12.5 4.5 16 8 8.5 15.5 4.5 16l.5-4Z" fill="none" stroke="currentColor" stroke-linejoin="round"/>',
  key:'<circle cx="9" cy="11" r="3.5" fill="none" stroke="currentColor"/><circle cx="14.5" cy="5.5" r="1.6" fill="none" stroke="currentColor"/>',
  recycle:'<path d="M5.5 5.5 15 13M13.5 4.2 16 5.2l-1.2-2.4ZM16.5 10.5V15a1.5 1.5 0 0 1-1.5 1.5H5A1.5 1.5 0 0 1 3.5 15v-2" fill="none" stroke="currentColor"/>',
  shield:'<path d="M10 2.8 16 5v5c0 3.9-2.4 6.4-6 7.2C6.4 16.4 4 13.9 4 10V5Z" fill="none" stroke="currentColor"/><path d="M7.8 10l1.6 1.6 2.8-3.2" fill="none" stroke="currentColor"/>',
  book:'<path d="M4 4.5A1.5 1.5 0 0 1 5.5 3H16v13H5.5A1.5 1.5 0 0 0 4 17.5Z" fill="none" stroke="currentColor"/><path d="M8 7h5M8 10h5" stroke="currentColor"/>'
};
function popup(title,msg){ esc(msg); }
function toast(msg,ms){
  var t=document.createElement('div');t.className='toast';t.textContent=msg;
  document.body.appendChild(t);
  setTimeout(function(){ t.style.opacity='0'; t.style.transition='opacity .2s'; },ms||1600);
  setTimeout(function(){ if(t.parentNode)t.parentNode.removeChild(t); }, ms||1900);
}
function showFloat(x,y,items){
  var m=document.createElement('ul'); m.className='float-menu';
  items.forEach(function(it){
    var li=document.createElement('li');
    li.className='float-menu__item'+(it.danger?' is-danger':'');
    if(it.sep){ li.className='menu-sep'; } else {
      li.innerHTML=(it.icon?('<span>'+svg(it.icon)+'</span>'):'')+'<span>'+esc(it.label)+'</span>';
      li.addEventListener('click',function(){
        closeFloat();
        if(it.fn)it.fn();
      });
    }
    m.appendChild(li);
  });
  document.body.appendChild(m);
  function placex(){
    var r=m.getBoundingClientRect();
    var X=Math.min(x,innerWidth-r.width-8),Y=Math.min(y,innerHeight-r.height-8);
    m.style.left=Math.max(8,X)+'px'; m.style.top=Math.max(8,Y)+'px';
  }
  placex();
  var dm=function(){closeFloat();document.removeEventListener('mousedown',dm);};
  setTimeout(function(){ document.addEventListener('mousedown',dm); },0);
  window.__mf=function(){ closeFloat(); };
}
function closeFloat(){ var m=document.querySelector('.float-menu'); if(m)m.remove(); }

/* 通用 Dialog */
function dialog(cfg){
  var mr=el('modalRoot'); if(!mr)return;
  var wrap=document.createElement('div'); wrap.className='modal-scrim';
  var body=cfg.section?cfg.section:
    '<div class="'+esc(cfg.cls||'dialog')+'">'+
      (cfg.title?('<h2 class="dialog__title">'+esc(cfg.title)+'</h2>'):'')+
      (cfg.msg?('<div class="dialog__msg">'+cfg.msg+'</div>'):'')+
      (cfg.form?'<div class="dlg-form">'+cfg.form+'</div>':'')+
      '<div class="dialog__actions">'+cfg.actions+'</div>'+
    '</div>';
  wrap.innerHTML=body;
  mr.appendChild(wrap);
  function cancel(){ if(wrap.parentNode)wrap.parentNode.removeChild(wrap); }
  wrap.addEventListener('mousedown',function(ev){ if(ev.target===wrap)cancel(); },false);
  // 内部临时只读: buttons data-ok bind once after
  Array.prototype.forEach.call(wrap.querySelectorAll('[data-act="ok"]'),function(b){
    b.addEventListener('click',function(){ var r=cfg.onOk?(cfg.onOk.bind(wrap))():true; if(r!==false)cancel(); });
  });
  Array.prototype.forEach.call(wrap.querySelectorAll('[data-act="no"]'),function(b){
    b.addEventListener('click',cancel);
  });
  return {close:cancel, scope:wrap};
}
/* danger confirm 统一 */
function confirmCtrl(label,desc,danger,onOk){
  dialog({
    title:esc(label),
    cls:'dialog',
    msg:(danger&&danger.kicker?('<p style="margin:0 0 6px;color:var(--danger);font-weight:600">'+esc(danger.kicker)+'</p>'):'')+'<div>'+desc+'</div>',
    actions:'<button class="btn btn--ghost" data-act="no">取消</button>'+
      '<button class="btn '+(danger?'btn--danger':'btn--primary')+'" data-act="ok">'+esc(danger?'确认'+ctrl:'确定')+'</button>',
    onOk:onOk
  });
}

/* 通用动作条: dialog 表单行 input */
function formRow(label,inputHTML){ return '<label class="form-field"><span class="field-label">'+esc(label)+'</span>'+inputHTML+'</label>'; }
function iw(id,val,ph){ return '<input class="inp" id="'+id+'" value="'+esc(val==null?'':val)+'" placeholder="'+esc(ph||'')+'"/>'; }

/* ---------- 通用表格构建 ---------- */
function tableNode(rows, cols, headExtras){
  // cols: [{label,cell(r),w,cls,head}]
  var thead='';
  var trows='';
  cols.forEach(function(c){
    var hd=c.head!=null?c.head:c.label;
    thead+='<th'+(c.w?' style="width:'+c.w+'"':'')+(c.hcl?' class="'+c.hcl+'"':'')+'>'+esc(hd)+'</th>';
  });
  (rows||[]).forEach(function(r,ri){
    var tds='';
    cols.forEach(function(c){
      var content;
      if(typeof c.cell==='function')content=c.cell(r,ri);
      else content=(r[c.keys]||'');
      tds+='<td'+(c.cl?' class="'+c.cl+'"':'')+'>'+content+'</td>';
    });
    trows+='<tr'+(r.sele?(' class="is-selected"'):'')+(r._tr?' '+r._tr:'')+'>'+tds+'</tr>';
  });
  var e=document.createElement('div');
  e.className='tbl-scroll';
  e.innerHTML='<table class="table-x"><thead><tr>'+thead+'</tr></thead><tbody>'+
    (trows||'<tr><td colspan="'+(cols.length||1)+'" class="empty-guide">'+esc(headExtras&&headExtras.empty||'暂无数据')+'</td></tr>')+
    '</tbody></table>';
  return e;
}
function badges(b){ return b.map(function(x){ return x.tag?('<span class="tag tag--'+x.t+'">'+(x.ico?'<i class="dot"></i>':'')+esc(x.t==='ok'||x.t==='warn'||x.t==='danger'?'':x.tag)+'</span>'):''; }).join(''); }
function humanGB(gb){
  if(gb>=1000)return (gb/1000).toFixed(gb>=10000?0:1)+' TB';
  return (gb<10?gb.toFixed(2):(gb%1?gb.toFixed(1):gb))+' GB';
}
function formGB(gb){ if(gb<1000)return gb+' GB'; return (gb/1000)+' TB'; }

/* 磁盘 GB -> 分区 */
function wrapTag(kind){
  var map={PERSONAL:['个人盘','primary'],'FOLDER-DRIVE':['部门盘','plain']};
  var m=map[kind]||[kind,'plain'];
  return '<span class="tag tag--'+m[1]+'">'+esc(m[0])+'</span>';
}

/* 顶层点击代理(命令类动作统一 bind 由各自页面负责) */
function on(rootSel,handler){
  var r=el(rootSel)||(this&&this._r)||document;
  r.addEventListener('click',handler,false);
}

root=el('aPageRoot');
el('aView');
var col={muted:'t-a'};

function section(title,sub){ return '<p class="a-nav-item--on"></p>'; }

/* 抽屉：基础/成员/配额/操作痕迹(重) ；接受 secs HTML */
function drawer(secs){
  var mr=el('modalRoot');
  var sc=document.createElement('div'); sc.className='drawer-scrim';
  var d=document.createElement('aside'); d.className='drawer'; d.style.width='560px';
  var head=secs.title||'';
  d.innerHTML=
    '<div class="drawer__head"><span>'+esc(head)+'</span><button class="icon-btn icon-btn--small" data-side-close>'+svg(IC.close)+'</button></div>'+
    '<div class="drawer__body">'+(secs.body||'')+'</div>';
  function close(){ if(sc.parentNode)sc.parentNode.removeChild(sc); if(d.parentNode)d.parentNode.removeChild(d); }
  sc.appendChild(d);
  mr.appendChild(sc);
  d.querySelector('[data-side-close]').addEventListener('click',close,false);
  sc.addEventListener('mousedown',function(ev){ if(ev.target===sc)close(); });
  return {node:d, close:close};
}
function splitKV(map){
  var s='<div class="drawer__body" style="padding:6px 16px">';
  for(var k in map)s+='<div class="a-kv"><dt>'+esc(k)+'</dt><dd>'+map[k]+'</dd></div>';
  return s+'</div>';
}

window.H={
  root:function(){return root;},
  setPage:function(html,onReady){ root.innerHTML='<div class="a-page">'+html+'</div>'; if(onReady)onReady(); },
  escape:esc, i:svg, IC:IC, toast:toast,
  dialog:dialog, confirm:function(t,d,onOk,dg){ confirmCtrl(t,d,dg,onOk); },
  float:showFloat, closeFloat:closeFloat, drawer:drawer,
  table:tableNode, formRow:formRow, iw:iw,
  tag:wrapTag, gb:humanGB, fgb:formGB, col:col, kv:splitKV, el:el,
  navswitch:function(name){ if(el('aView'))el('aView').setAttribute('data-page',name); }
};
window.HF = {
  T:function(name,coldefs,rows){
    return tableNode(rows,coldefs);
  }
};
/* nav dot 自动 */
})();
