/* ================================================================
   admin-pages-gov.js -- 治理中心页面块  (data-page: filegov / quota)
   纯前端 Mock：无后端 / 无第三方依赖 / 无 emoji；复用 window.H 与 UI 样式。
   写 / 删仅 UI 小步 + H.toast（演示数据），不做持久化。
   注册 window.Routes['filegov'] 与 ['quota']，由导航点击对应 data-page
   触发内部渲染（H.setPage）。文件由单一 IIFE 组装。
   ================================================================ */
(function () {
'use strict';

if (typeof window === 'undefined') return;
var Routes = window.Routes = window.Routes || {};
var H = window.H;

function esc(s) {
  s = s == null ? '' : s;
  return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}
function ic(path) {
  return '<svg viewBox="0 0 20 20" width="15" height="15" aria-hidden="true">' + path + '</svg>';
}
var IC = {
  refresh: '<path d="M11 2.5 5 11h4l-1 6.5 6-8.5h-4l1-6.5Z" fill="none" stroke="currentColor" stroke-linejoin="round"/>',
  check: '<path d="M4 10.5l3.5 3.5L16 6.5" fill="none" stroke="currentColor"/>',
  folder: '<path d="M2.5 6A1.5 1.5 0 0 1 4 4.5h3.4l1.6 1.8H16A1.5 1.5 0 0 1 17.5 7.8V15A1.5 1.5 0 0 1 16 16.5H4A1.5 1.5 0 0 1 2.5 15Z" fill="none" stroke="currentColor" stroke-linejoin="round"/>',
  dustbin: '<path d="M4.5 6h11M8 3.8h4l1.7 2.2H6.3L8 3.8ZM6 6l.5 9a1.5 1.5 0 0 0 1.5 1.4h4A1.5 1.5 0 0 0 13.5 15L14 6" fill="none" stroke="currentColor" stroke-linejoin="round"/>',
  flag: '<path d="M5 17V3.5M5 4.5h8.5l-1.5 3 1.5 3H5" fill="none" stroke="currentColor" stroke-linejoin="round"/>'
};
function pageHead(t, s) {
  return '<header class="a-head"><h1>' + esc(t) + '</h1><span class="a-head__sub">' + esc(s) + '</span></header>';
}
function tag(kind, text) {
  var m = { file: 'primary', ok: 'ok', warn: 'warn', danger: 'danger', folder: 'plain' };
  return '<span class="tag tag--' + (m[kind] || 'plain') + '">' + esc(text) + '</span>';
}
function th(w, label, cls) {
  return '<th style="width:' + w + '"' + (cls ? ' class="' + cls + '"' : '') + '>' + esc(label) + '</th>';
}
function tdCell(html, n) {
  return '<td style="padding:0 ' + (n || 12) + 'px">' + html + '</td>';
}
function linkRow(acts) {
  var o = '';
  for (var i = 0; i < acts.length; i++) o += '<a class="t-a' + (acts[i].d ? ' is-danger' : '') + '" data-a="' + acts[i].a + '" data-i="' + acts[i].i + '">' + esc(acts[i].t) + '</a>';
  return '<div class="rest">' + o + '</div>';
}
function tdOp(op) { /* op = {a,i,t,d} */ return '<td style="width:110px"><div class="rest">' + '<a class="t-a' + (op.d ? ' is-danger' : '') + '" data-a="' + op.a + '" data-i="' + op.i + '">' + esc(op.t) + '</a></div></td>'; }
function ext(n) { var m = n.match(/\.([A-Za-z0-9]+)$/); return m ? m[1].toUpperCase() : '文件'; }
function pillBadge(n) { return '<span class="pill-badge">' + esc(n) + '</span>'; }

/* =================================================================
   data-page: filegov — 文件 / 回收站治理（治理定位 · 非代删）
   ================================================================= */
Routes['filegov'] = (function () {
  var SCOPES = ['研发部（部门盘）', '生产部（部门盘）', '销售部（部门盘）', '张研（个人盘）', '李四（个人盘）'];
  var curS = 0;   // scope index
  var tabI = 0;   // 0 文件浏览 / 1 回收站
  var TRASH = [
    { p: '/研发部/产品资料/2026/设计图纸/DWG-001-H组装.dwg', by: '王五', at: '2026-09-04 09:31', keep: 12, sz: '24.6 GB', ok: true },
    { p: '/研发部/工艺文件/2026Q3 工艺规划.xlsx', by: '李四', at: '2026-09-02 16:02', keep: 5, sz: '0.9 GB', ok: true },
    { p: '/研发部/测试数据/压测记录-oldV3.log', by: '赵六', at: '2026-08-31 11:20', keep: 2, sz: '6.4 GB', ok: true },
    { p: '/生产部/设备档案/退线夹具-archive.dwg', by: '郑八', at: '2026-09-01 14:05', keep: 19, sz: '3.1 GB', ok: true },
    { p: '/销售部/线索管理/重复导入批次.bak', by: '孙丽', at: '2026-08-27 10:10', keep: 30, sz: '0.4 GB', ok: true },
    { p: '/张研/我的文档/草稿/旧简历-2025.zip', by: '张研', at: '2026-08-25 09:40', keep: 0, sz: '0.2 GB', ok: false }
  ];
  var FILE = {
    0: [
      ['DWG-001-H组装.dwg', '/研发部/产品资料/2026/设计图纸', '24.6 GB', '2026-09-04 10:21', '王五'],
      ['设备平台模型_G3.step', '/研发部/产品资料/2026', '86.2 GB', '2026-09-03 18:42', '张三'],
      ['技术规格表-终审.xlsx', '/研发部/工艺文件', '0.9 GB', '2026-09-02 15:20', '李四'],
      ['拓扑验证报告-Final.pdf', '/研发部/测试数据', '2.1 GB', '2026-09-01 09:44', '赵六'],
      ['渲染源文件-项目A.zip', '/研发部/市场支撑/渲染', '12.4 GB', '2026-08-30 11:02', '王五'],
      ['元器件采购清单Q3.xlsx', '/研发部/采购', '1.0 GB', '2026-08-28 16:18', '钱七']
    ],
    1: [['产线点检表-5号线.xlsx', '/生产部/工艺文件', '0.5 GB', '2026-09-04 08:12', '郑八'],
      ['作业指导书-冲压A.pdf', '/生产部/工艺文件', '1.8 GB', '2026-09-02 13:40', '郑八'],
      ['设备图纸M6-工位.step', '/生产部/设备档案', '14.0 GB', '2026-08-31 10:05', '吴九']],
    2: [['海外报价单-统单.pdf', '/销售部/报价归档', '1.2 GB', '2026-09-03 15:12', '孙丽'],
      ['客户线索池-清洗.xlsx', '/销售部/线索管理', '9.9 GB', '2026-09-01 11:22', '孙丽']],
    3: [['个人2026作品集.pdf', '/我的文档/作品集', '1.3 GB', '2026-09-02 20:41', '张研'],
      ['家庭影像-整理优化.zip', '/我的文档/备份', '8.1 GB', '2026-08-26 22:10', '张研'],
      ['随笔随感.xlsx', '/我的文档/汇总', '0.04 GB', '2026-08-24 09:00', '张研']],
    4: [['获奖证书扫描-2025.pdf', '/我的文档/证书', '0.6 GB', '2026-09-01 19:05', '李四'],
      ['参考零件模型.step', '/设计/临期归档', '18.2 GB', '2026-08-29 08:33', '李四']]
  };

  function rows() { return FILE[curS] || []; }
  function scOpts() {
    var h = '';
    for (var i = 0; i < SCOPES.length; i++) h += '<option value="' + i + '"' + (i === curS ? ' selected' : '') + '>' + esc(SCOPES[i]) + '</option>';
    return h;
  }
  function remainBox(d) {
    if (d <= 0) return tag('danger', '已过保留期');
    if (d <= 5) return tag('danger', d + ' 天');
    if (d <= 15) return tag('warn', d + ' 天');
    return tag('ok', d + ' 天');
  }
  function rName(p) { var a = p.split('/'); return a[a.length - 1]; }

  function filesView() {
    var rr = rows();
    var h = '<div class="tbl-scroll"><table class="table-x"><thead><tr>' +
      th('26%', '名称') + th('34%', '所属目录路径') + th('11%', '大小') + th('15%', '修改时间') + th('14%', '归属人')
      + '</tr></thead><tbody>';
    for (var i = 0; i < rr.length; i++) {
      var r = rr[i];
      h += '<tr>' + tdCell('<div class="tb-2line"><span class="tl">' + tag('file', ext(r[0])) + ' ' + esc(r[0]) + '</span>' +
        '<span class="ts">' + esc(r[0]) + '</span></div>', 12) + tdCell('<span class="u-faint">' + esc(r[1]) + '</span>', 12) +
        tdCell(esc(r[2]), 12) + tdCell(esc(r[3]), 12) + tdCell(esc(r[4]), 12) +
        '<td style="width:110px"><div class="rest"><a class="t-a is-danger" data-a="loc">定位回收</a></div></td>' + '</tr>';
      /* 定位回收 danger 链接走对话框确认 */
    }
    return h + '</tbody></table></div>';
  }
  function trashView() {
    var h = '<div class="tbl-scroll"><table class="table-x"><thead><tr>' +
      th('34%', '原始路径 / 回收', '') + th('24%', '删除人 / 时间') + th('13%', '保留剩余') + th('10%', '大小') + th('', '操作', 't-a')
      + '</tr></thead><tbody>';
    for (var i = 0; i < TRASH.length; i++) {
      var r = TRASH[i];
      h += '<tr>' +
        tdCell('<div class="tb-2line"><span class="tl">' + esc(rName(r.p)) + '</span>' +
        '<span class="ts">' + esc(r.p) + '</span></div>', 12) +
        tdCell('<div class="tb-2line"><span class="tl">' + esc(r.by) + '</span><span class="ts">' + esc(r.at) + '</span></div>', 12) +
        tdCell(remainBox(r.keep), 12) + tdCell(esc(r.sz), 12) +
        '<td style="width:150px"><div class="rest">' +
        (r.ok ? '<a class="t-a" data-a="recover" data-i="' + i + '">恢复</a>' : '<span class="u-faint">—</span>') +
        '<a class="t-a is-danger" data-a="purge" data-i="' + i + '">彻底删除</a></div></td>' + '</tr>';
    }
    return h + '</tbody></table></div>';
  }

  function contentHTML() {
    var body;
    var heads;
    if (tabI === 0) {
      body = filesView();
      heads = '文件清单 · 所属：' + esc(SCOPES[curS]);
    } else {
      body = trashView();
      heads = '回收站（按所辖空间） · ' + TRASH.length + ' 条';
    }
    return '<div class="filters" style="margin:4px 0 10px">' +
      '<span class="fl"><span>范围（所辖）</span>' +
      '<select class="sel" data-fgScope style="width:200px">' + scOpts() + '</select></span>' +
      '<span class="spacer"></span>' +
      '<span class="result" data-count></span>' +
      '<button class="btn btn--ghost" data-refresh>' + ic(IC.refresh) + '刷新（演示）</button>' +
      '</div>' +
      '<nav class="tabbar">' +
      '<button class="tab' + (tabI === 0 ? ' tab--on' : '') + '" data-tab="0">' + ic(IC.folder) + '文件 · 浏览 ' + pillBadge(rows().length) + '</button>' +
      '<button class="tab' + (tabI === 1 ? ' tab--on' : '') + '" data-tab="1">' + ic(IC.dustbin) + '回收站 ' + pillBadge(TRASH.length) + '</button>' +
      '<span class="spacer"></span>' +
      '<button class="btn btn--danger btn--small" data-empty>' + ic(IC.dustbin) + '清空回收站</button>' +
      '</nav>' +
      '<section class="panel" style="flex:1;min-height:0">' +
      '<div class="panel__head"><span class="t">' + (tabI === 0 ? '文件 · 浏览' : '回收站（按所辖空间）') + '</span><span class="u">' + heads + '</span></div>' +
      '<div class="panel__body">' + body + '</div></section>' +
      '<p class="x-note" style="font-size:12px;color:var(--text-3);padding:8px 2px 0">治理仅限所辖空间不代删：“定位回收”只引导到该空间可逆回收站，不做跨空间全局删除。以上全部为演示数据。</p>';
  }

  function render() {
    H.setPage(pageHead('文件 / 回收站治理', '治理：“定位回收”只引导进入可逆回收路径；管理员不得越空间清零删除。') + contentHTML());
  }
  function draw() {
    var sel = document.querySelector('[data-fgScope]');
    if (sel && +sel.value !== curS) curS = +sel.value;
    var tabs = document.querySelectorAll('.tab[data-tab]');
    for (var i = 0; i < tabs.length; i++) tabs[i].className = 'tab' + (+tabs[i].getAttribute('data-tab') === tabI ? ' tab--on' : '');
    var main = document.querySelector('.panel__body');
    var count = document.querySelector('[data-count]');
    if (count) count.textContent = '共 ' + rows().length + ' 条 · ' + esc(SCOPES[curS]) + '（演示数据）';
    if (!main) return;
    main.innerHTML = tabI === 0 ? filesView() : trashView();
  }
  function bind() {
    var root = H.root();
    if (!root) return;
    function once(sel, type, fn) { var e = root.querySelector(sel); if (e) e.addEventListener(type, fn); }
    once('[data-tab="0"]', 'click', function () { tabI = 0; draw(); });
    once('[data-tab="1"]', 'click', function () { tabI = 1; draw(); });
    once('[data-refresh]', 'click', function () { draw(); H.toast('演示快照已刷新'); });
    once('[data-empty]', 'click', function () {
      if (!TRASH.length) { H.toast('回收站已空'); return; }
      H.dialog({
        title: '清空回收站',
        cls: 'dialog',
        msg: '<div>将把<b>当前范围</b>回收站的 ' + esc(TRASH.length) + ' 条彻底删除。清空为整批不可逆操作，仅按当前所辖空间作用（演示 mock，仅本会话）。</div>',
        actions: '<button class="btn btn--ghost" data-act="no">取消</button>' +
          '<button class="btn btn--danger" data-act="ok">清空并删除</button>',
        onOk: function () { TRASH.length = 0; draw(); H.toast('回收站已清空（演示数据）'); }
      });
    });
    once('[data-fgScope]', 'change', function (e) { curS = +e.target.value; draw(); H.toast('已切换"范围"演示快照到：' + esc(SCOPES[curS])); });
    /* 行级操作统一委托在持久 container（draw 仅重刷其 inner，不移除监听）。 */
    var main = root.querySelector('.panel__body');
    if (main) {
      main.addEventListener('click', function (e) {
        var a = e.target && e.target.closest ? e.target.closest('[data-a]') : null;
        if (!a) { return; }
        var kind = a.getAttribute('data-a');
        if (kind === 'loc') {
          H.dialog({
            title: '定位回收',
            cls: 'dialog',
            msg: '<div>将把该对象引入其所在空间的“回收站”，保留恢复入口。治理定位可逆，不跨空间“物理删除”。</div>',
            actions: '<button class="btn btn--ghost" data-act="no">取消</button>' +
              '<button class="btn btn--primary" data-act="ok">转至回收站定位</button>',
            onOk: function () { H.toast('已定位到该空间回收站（可逆治理，演示数据）'); }
          });
          return;
        }
        var i = +a.getAttribute('data-i');
        var tr = TRASH[i];
        if (!tr) return;
        if (kind === 'recover') {
          TRASH.splice(i, 1); draw();
          H.toast('已恢复「' + rName(tr.p) + '」（原位若被占用将自动改名，演示数据）');
        } else if (kind === 'purge') {
          var rm = tr;
          H.dialog({
            title: '彻底删除（危险）',
            cls: 'dialog',
            msg: '<div>将把该回收对象彻底移出回收站且<b>不可恢复</b>。仅针对单条回收对象，不做跨空间清除。确认此自删操作（演示 mock，仅本会话）。</div>',
            actions: '<button class="btn btn--ghost" data-act="no">取消</button>' +
              '<button class="btn btn--danger" data-act="ok">确认彻底删除</button>',
            onOk: function () {
              var at = TRASH.indexOf(rm); if (at >= 0) TRASH.splice(at, 1); draw(); H.toast('已彻底删除（演示数据）');
            }
          });
        }
      }, true);
    }
  }

  return function () {
    curS = 0; tabI = 0; /* 幂等重置快照，避免跨页脏状态 */
    render();
    setTimeout(bind, 0);
  };
})();

/* =================================================================
   data-page: quota — 配额管理（三态 used / reserved / quota）
   ================================================================= */
Routes['quota'] = (function () {
  var Q = [
    { name: '研发部（部门盘）', kind: 1, quota: 1000, used: 828, res: 96, over: false },
    { name: '生产部（部门盘）', kind: 1, quota: 500, used: 420, res: 0, over: false },
    { name: '销售部（部门盘）', kind: 1, quota: 800, used: 386, res: 40, over: false },
    { name: '张研（个人盘）', kind: 0, quota: 200, used: 89, res: 5, over: false },
    { name: '李四（个人盘）', kind: 0, quota: 200, used: 214, res: 0, over: true },
    { name: '王五（个人盘）', kind: 0, quota: 50, used: 22.6, res: 12, over: false },
    { name: '赵六（个人盘）', kind: 0, quota: 50, used: 49.8, res: 0, over: false }
  ];
  var DEF = { p: 200, f: 500 };

  function overQB(x) { return x.over || x.used + x.res - x.quota > 1e-6; }
  function norm(x) { if (overQB(x)) x.over = true; else x.over = false; }

  function rowQ(x, i) {
    var used = Math.min(x.used / x.quota * 100, 100);
    var res = Math.min(x.res / x.quota * 100, Math.max(0, 100 - used));
    var segs = '<i style="background:var(--primary);width:' + used + '%"></i>';
    segs += '<i style="background:var(--warn);width:' + res + '%"></i>';
    if (overQB(x)) segs += '<i class="dq-over" style="width:3%"></i>';
    return '<tr>' +
      '<td>' + esc(x.name) + '</td>' +
      '<td>' + tag(x.kind ? 'folder' : 'file', x.kind ? '部门盘' : '个人盘') + '</td>' +
    /* quota列 */
      '<td class="t-a">' + '<b>' + (x.quota >= 1000 ? (x.quota / 1000) + ' TB' : x.quota + ' GB') + '</b></td>' +
      '<td><span class="dq-bar">' + segs + '</span><span class="x-nums">已用 ' + x.used + ' GB · 已预留 ' + x.res + ' GB</span></td>' +
      '<td>' + (overQB(x) ? tag('danger', '超配额') : tag('ok', '正常')) + '</td>' +
      '<td style="width:70px"><div class="rest"><a class="t-a" data-a="edit-quota" data-i="' + i + '">修改</a></div></td>' +
      '</tr>';
  }

  function quotaPage() {
    var html = pageHead('配额管理', '三态：已用 + 已预留（reserved）须 ≤ quota；可用 = quota − used − reserved（演示数据）。') +
      '<div class="form-sec" style="margin:6px 0 16px"><div class="form-sec__t">默认策略 <small style="margin-left:10px">策略为全局默认，可被具体空间配额覆盖</small>' +
      '<button class="btn btn--ghost btn--small" data-sdef>保存(mock)</button></div><div class="form-sec__b">' +
      '<label class="form-field"><span class="field-label">个人盘 Profile 默认配额</span>' +
      '<select class="sel" data-defp>' + selOpt('p') + '</select></label>' +
      '<label class="form-field"><span class="field-label">部门盘默认配额</span>' +
      '<select class="sel" data-deff>' + selOpt('f') + '</select></label>' +
      '<div class="wide" style="width:100%;grid-column:1/-1;font-size:12px;color:var(--text-3)">说明：上为全局默认；具体空间（下表）可“修改”做个性化覆盖。</div></div></div>' +
      '<div class="panel" style="min-width:0"><div class="panel__head"><span class="t">空间配额（三态条）</span>' +
      '<span class="u">主蓝＝已用 · 琥珀＝预留 · 灰＝剩余可用；‘超配额’行末红色报警</span></div>' +
      '<div class="panel__body" style="overflow:auto"><table class="table-x"><thead><tr>' +
      th('', '空间名称') + th('', '类型') + th('', '总量(quota)') + th('', '容量状态三态') + th('', '状态') + th('', '操作')
      + '</tr></thead><tbody>' + Q.map(rowQ).join('\n') + '</tbody></table>' +
      '<div class="cap3"></div></div></div>' +
      '<p class="u-faint" style="padding:8px 2px 0">修改后的 quota 不可小于当行 used + reserved；低于阈值会将保存按钮禁用且实时红字提示（仅客户端 mock 校验）。</p>';
    return html;
  }
  function selOpt(k) {
    var arr = k === 'p' ? [50, 100, 200] : [200, 500, 1000];
    var cur = k === 'p' ? DEF.p : DEF.f;
    var s = '';
    for (var i = 0; i < arr.length; i++) {
      var g = arr[i];
      s += '<option value="' + g + '"' + (g === cur ? ' selected' : '') + '>' + g + ' GB</option>';
    }
    return s;
  }

  function openEditDialog(a, e) {
    e && e.preventDefault();
    var i = +a.getAttribute('data-i');
    var q = Q[i];
    var need = Math.round((q.used + q.res) * 10) / 10;
    var formMsg = q.over
      ? '<div data-msg class="x-msg" style="color:var(--danger);font-size:12px;margin:0 0 6px;white-space:normal">当前为超配额状态（红帽示意），新配额须 ≥ used＋reserved。</div>'
      : '<div data-msg class="x-msg" style="min-height:14px;font-size:12px;margin:2px 0;color:var(--text-3)">（预留）</div>';

    var dlg = H.dialog({
      title: '修改配额 · ' + q.name,
      cls: 'dialog',
      form: '<div class="field-label" style="margin-bottom:4px">新 total 配额（单位 GB，最小 1）</div>' +
        '<input class="inp" data-quota type="number" step="0.1" min="1" value="' + q.quota + '" style="width:130px"/>' +
        formMsg +
        '<div style="font-size:12px;color:var(--text-2)">本空间当前：已用 ' + q.used + ' GB ＋ 已预留 ' + q.res +
        ' GB ＝ 下限 ' + need + ' GB（配额不可低于该值）。</div>',
      actions: '<button class="btn btn--ghost" data-act="no">取消</button>' +
        '<button class="btn btn--primary" data-save-q data-act="ok">保存</button>',
      onOk: function () {
        var box = dlg && dlg.scope;
        if (!box) return false;
        var inpEl = box.querySelector('[data-quota]');
        var msg = box.querySelector('[data-msg]');
        var num = Number(inpEl.value);
        if (!num || num < need || !isFinite(num)) {
          inpEl.style.borderColor = 'var(--danger)';
          inpEl.style.background = 'var(--danger-soft)';
          if (msg) { msg.style.color = 'var(--danger)'; msg.textContent = '客户端校验：新配额不得小于 used＋reserved = ' + need + ' GB，已阻止提交。'; }
          return false;   /* 守卫框留红错，不放行（关闭由用户点取消） */
        }
        q.quota = num;
        norm(q);
        rebuild();
        H.toast('配额已更新为 ' + num + ' GB（演示数据），三态条已按新 quota 重算');
      }
    });
    if (!dlg || !dlg.scope) return;
    var input = dlg.scope.querySelector('[data-quota]');
    var err = dlg.scope.querySelector('[data-msg]');
    var saveBtn = dlg.scope.querySelector('[data-save-q]');
    /* 实施校验：非法→红字并禁用“保存”；合法→解除禁用。liveChange 实时。 */
    var check = function () {
      var v = Number(input.value);
      var bad = !isFinite(v) || isNaN(v) || v <= 0 || v < need;
      if (bad) {
        input.style.borderColor = 'var(--danger)';
        input.style.background = 'var(--danger-soft)';
        err.style.color = 'var(--danger)';
        err.textContent = v <= 0 || isNaN(v) ? '请输入大于 0 的数字。' : ('错误：新配额 ' + v + ' GB 低于下限 ' + need + ' GB。');
        if (saveBtn) saveBtn.disabled = true;
      } else {
        input.style.borderColor = '';
        input.style.background = '';
        err.style.color = 'var(--text-3)';
        err.textContent = '可通过校验（≥ 下限）';
        if (saveBtn) saveBtn.disabled = false;
      }
    };
    input.addEventListener('input', check);
    input.addEventListener('focus', function () { input.select(); });
    check();   /* 初始即驱动一次；超配额行的初始期望合法（现有 quota≥need?）由于超配 used+res>quota 时下限可能>初 quota → 初禁用并显红错，符合规格 */
  }
  function rebuild() {
    baseRender();
  }
  var dqDelegated = false;
  function bind() {
    var root = H.root();
    if (!root) return;
    function once(sel, type, fn) { var el = root.querySelector(sel); if (el) el.addEventListener(type, fn); }
    once('[data-sdef]', 'click', function () { H.toast('已“保存”默认策略（mock，仅本会话）'); });
    once('[data-defp]', 'change', function (e) { DEF.p = +e.target.value; });
    once('[data-deff]', 'change', function (e) { DEF.f = +e.target.value; });
    if (!dqDelegated) {
      dqDelegated = true;   /* 委托挂在常驻 root 上只绑一次，避免多次渲染后重复触发 */
      root.addEventListener('click', function (e) {
        var a = e.target.closest ? e.target.closest('a[data-a="edit-quota"]') : null;
        if (a) openEditDialog(a, e);
      });
    }
  }
  function baseRender() {
    H.setPage(quotaPage());
    bind();
  }
  function render() {
    baseRender();
  }
  return function () { render(); };
})();

Routes.GOV_END_FLAG = 1;
})();
